from core.base_tool import BaseMCPTool
import requests, os

class PsychExpertTool(BaseMCPTool):
    def register_tools(self):
        @self.mcp.tool()
        def expert_chat(user_id: str, query: str) -> dict:
            '''心理专家问答工具'''
            try:
                resp = requests.post(
                    os.getenv("PSYCH_API_URL", "http://127.0.0.1:5000/api/chat"),
                    json={"user_id": user_id, "text": query},
                    timeout=20
                )
                data = resp.json()
                return {"success": True, "reply": data.get("reply", "")}
            except Exception as e:
                return {"success": False, "error": str(e)}

if __name__ == "__main__":
    PsychExpertTool("PsychExpert").run()
