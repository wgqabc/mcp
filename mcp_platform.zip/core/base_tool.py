from mcp.server.fastmcp import FastMCP
import logging

class BaseMCPTool:
    def __init__(self, name: str):
        self.mcp = FastMCP(name)
        self.logger = logging.getLogger(name)
        self.register_tools()

    def register_tools(self):
        raise NotImplementedError

    def run(self):
        self.mcp.run(transport="stdio")
