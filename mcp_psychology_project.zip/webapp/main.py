from flask import Flask, render_template, request, redirect, session
from database.models import init_db

app = Flask(__name__)
app.secret_key = "secret123"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session['user'] = request.form['username']
        return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    user = session.get('user')
    if not user:
        return redirect('/login')
    return render_template('dashboard.html', user=user)

if __name__ == "__main__":
    init_db()
    app.run(host='0.0.0.0', port=8080)
