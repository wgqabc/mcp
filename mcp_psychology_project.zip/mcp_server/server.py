from mcp.server.fastmcp import FastMCP
import logging, sys, json

logger = logging.getLogger('PsychologyMCP')

if sys.platform == 'win32':
    sys.stderr.reconfigure(encoding='utf-8')
    sys.stdout.reconfigure(encoding='utf-8')

mcp = FastMCP("PsychologyMCP")

@mcp.tool()
def get_psychology_answer(question: str) -> dict:
    '''Return expert-based psychology advice'''
    logger.info(f"Received question: {question}")
    return {"success": True, "answer": f"心理专家建议：保持积极心态，适当休息，深呼吸放松。您提到的问题是：{question}"}

if __name__ == "__main__":
    mcp.run(transport="stdio")
