import asyncio, websockets, subprocess, os, json, sys, logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger('MCP_PIPE')

async def connect(uri, target):
    async with websockets.connect(uri) as websocket:
        logger.info("Connected to remote MCP manager")
        process = subprocess.Popen(
            ["python", target], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        async def ws_to_proc():
            while True:
                msg = await websocket.recv()
                process.stdin.write(msg + "\n")
                process.stdin.flush()
        async def proc_to_ws():
            while True:
                data = await asyncio.to_thread(process.stdout.readline)
                if not data:
                    break
                await websocket.send(data)
        await asyncio.gather(ws_to_proc(), proc_to_ws())

if __name__ == "__main__":
    uri = os.environ.get("MCP_ENDPOINT", "wss://example.com/mcp")
    asyncio.run(connect(uri, "mcp_server/server.py"))
