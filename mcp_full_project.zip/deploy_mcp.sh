#!/bin/bash
# deploy_mcp.sh - 一键部署 MCP 心理专家平台

# ------------------------------
# 1. 更新系统并安装依赖
# ------------------------------
echo "更新系统并安装依赖..."
sudo apt update
sudo apt install -y python3 python3-venv python3-pip mysql-server unzip

# ------------------------------
# 2. MySQL 配置
# ------------------------------
DB_NAME="mcp"
DB_USER="mcp_user"
DB_PASSWORD="*#06#Bcore*#06#"

echo "启动 MySQL 并创建数据库和用户..."
sudo systemctl enable mysql
sudo systemctl start mysql

sudo mysql -u root <<EOF
CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
EOF

# ------------------------------
# 3. 解压项目并进入目录
# ------------------------------
PROJECT_ZIP="mcp_full_project.zip"
PROJECT_DIR="mcp_full_project"

if [ -f "$PROJECT_ZIP" ]; then
    echo "解压 $PROJECT_ZIP..."
    unzip -o $PROJECT_ZIP -d .
else
    echo "未找到 $PROJECT_ZIP，请先上传 zip 包"
    exit 1
fi

cd $PROJECT_DIR || exit 1

# ------------------------------
# 4. 创建 Python 虚拟环境并安装依赖
# ------------------------------
echo "创建虚拟环境并安装依赖..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn sqlalchemy pymysql passlib[bcrypt] websockets python-dotenv

# ------------------------------
# 5. 初始化数据库
# ------------------------------
echo "初始化数据库表..."
python3 -c "from backend.database.init_db import init_db; init_db()"

# ------------------------------
# 6. 启动后端服务（后台）
# ------------------------------
echo "启动 FastAPI 后端..."
nohup venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000 > backend.log 2>&1 &

# ------------------------------
# 7. 启动 MCP 工具（后台）
# ------------------------------
echo "启动心理专家 MCP 工具..."
nohup venv/bin/python3 mcp_pipe.py > mcp.log 2>&1 &

# ------------------------------
# 8. 部署完成
# ------------------------------
echo "部署完成！"
echo "后端接口: http://<服务器IP>:8000"
echo "前端: 上传 frontend/index.html 到 Web 服务器访问"
echo "日志: backend.log 和 mcp.log"
# ------------------------------
# 8. 创建 systemd 服务
# ------------------------------
echo "创建 systemd 服务..."

# 后端
sudo bash -c 'cat > /etc/systemd/system/mcp_backend.service <<EOF
[Unit]
Description=MCP 心理专家平台后端服务
After=network.target mysql.service
Requires=mysql.service

[Service]
Type=simple
User=admin
WorkingDirectory=/home/admin/mcp_full_project
Environment="PATH=/home/admin/mcp_full_project/venv/bin"
ExecStart=/home/admin/mcp_full_project/venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5
StandardOutput=append:/home/admin/mcp_full_project/backend.log
StandardError=append:/home/admin/mcp_full_project/backend.log

[Install]
WantedBy=multi-user.target
EOF'

# MCP 工具
sudo bash -c 'cat > /etc/systemd/system/mcp_tool.service <<EOF
[Unit]
Description=MCP 心理专家工具服务
After=network.target mcp_backend.service
Requires=mcp_backend.service

[Service]
Type=simple
User=admin
WorkingDirectory=/home/admin/mcp_full_project
Environment="PATH=/home/admin/mcp_full_project/venv/bin"
ExecStart=/home/admin/mcp_full_project/venv/bin/python3 mcp_pipe.py
Restart=always
RestartSec=5
StandardOutput=append:/home/admin/mcp_full_project/mcp.log
StandardError=append:/home/admin/mcp_full_project/mcp.log

[Install]
WantedBy=multi-user.target
EOF'

sudo systemctl daemon-reload
sudo systemctl enable mcp_backend
sudo systemctl enable mcp_tool
sudo systemctl start mcp_backend
sudo systemctl start mcp_tool

echo "部署完成！后端和 MCP 工具已设置为 systemd 服务自启。"

