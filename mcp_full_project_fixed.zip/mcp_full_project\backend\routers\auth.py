from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from database.models import SessionLocal, User
from sqlalchemy.orm import Session
from passlib.hash import bcrypt

router = APIRouter()

class RegisterRequest(BaseModel):
    username: str
    password: str

class LoginRequest(BaseModel):
    username: str
    password: str

@router.post("/register")
def register(req: RegisterRequest):
    db: Session = SessionLocal()
    if db.query(User).filter(User.username == req.username).first():
        raise HTTPException(status_code=400, detail="用户名已存在")
    user = User(username=req.username, password_hash=bcrypt.hash(req.password))
    db.add(user)
    db.commit()
    return {"success": True}

@router.post("/login")
def login(req: LoginRequest):
    db: Session = SessionLocal()
    user = db.query(User).filter(User.username == req.username).first()
    if not user or not bcrypt.verify(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    return {"success": True, "role": user.role}
