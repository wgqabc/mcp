from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import auth, report, knowledge
from database.init_db import init_db

app = FastAPI(title="MCP心理专家平台")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(report.router, prefix="/report", tags=["Report"])
app.include_router(knowledge.router, prefix="/knowledge", tags=["Knowledge"])

@app.get("/")
async def root():
    return {"message": "MCP心理专家平台后端运行中"}
