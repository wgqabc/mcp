from fastapi import APIRouter
from pydantic import BaseModel
from database.models import SessionLocal, Knowledge
from sqlalchemy.orm import Session

router = APIRouter()

class KnowledgeItem(BaseModel):
    question: str
    answer: str

@router.get("/")
def list_knowledge():
    db: Session = SessionLocal()
    items = db.query(Knowledge).all()
    return {"items": [{"id": k.id, "question": k.question, "answer": k.answer} for k in items]}

@router.post("/")
def add_knowledge(item: KnowledgeItem):
    db: Session = SessionLocal()
    k = Knowledge(question=item.question, answer=item.answer)
    db.add(k)
    db.commit()
    return {"success": True}
