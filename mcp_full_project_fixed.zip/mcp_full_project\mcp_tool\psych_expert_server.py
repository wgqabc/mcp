# psych_expert_server.py
from mcp.server.fastmcp import FastMCP
import logging
import sys
import os
from dotenv import load_dotenv
import pymysql

load_dotenv()
logger = logging.getLogger("PsychExpert")
logging.basicConfig(level=logging.INFO)

if sys.platform == 'win32':
    sys.stderr.reconfigure(encoding='utf-8')
    sys.stdout.reconfigure(encoding='utf-8')

mcp = FastMCP("PsychExpert")

# Simple in-memory fallback knowledge base
knowledge_base = {
    "焦虑": "当感到焦虑时，试着做几次深呼吸，告诉自己这是暂时的情绪。",
    "失眠": "建立固定的作息，睡前减少电子设备使用，必要时咨询专业医生或心理咨询师。",
    "抑郁": "如果长期情绪低落，建议寻求专业帮助。"
}

def get_db_connection():
    # Connect using environment vars for optional report-based answers
    host = os.getenv('MYSQL_HOST', '127.0.0.1')
    port = int(os.getenv('MYSQL_PORT', '3306'))
    user = os.getenv('MYSQL_USER', 'root')
    pwd = os.getenv('MYSQL_PASSWORD', '')
    db = os.getenv('MYSQL_DB', 'mcpdb')
    try:
        conn = pymysql.connect(host=host, user=user, password=pwd, port=port, db=db, charset='utf8mb4')
        return conn
    except Exception as e:
        logger.warning(f"DB connect failed: {e}")
        return None

@mcp.tool()
def ask_expert(question: str, user_id: int = None) -> dict:
    """Return an answer tailored by matching keywords and optionally user latest report."""
    # First try keyword match
    for k, v in knowledge_base.items():
        if k in question:
            return {"success": True, "answer": v}
    # If user_id provided, try to fetch latest report and customize reply
    if user_id:
        conn = get_db_connection()
        if conn:
            with conn.cursor() as cur:
                sql = "SELECT content FROM reports WHERE user_id=%s AND is_latest=1 LIMIT 1"
                cur.execute(sql, (user_id,))
                row = cur.fetchone()
                if row and row[0]:
                    report = row[0]
                    # basic tailoring: echo that we read the report
                    reply = f"我看过你的最近心理报告摘要：{report[:300]}。基于这些信息，我建议你……（示例建议）"
                    return {"success": True, "answer": reply}
    # Fallback generic reply
    return {"success": True, "answer": "我理解你的感受。请你再多说一些具体的情况，或者问我一个更具体的问题。"}

if __name__ == '__main__':
    mcp.run(transport='stdio')
