#!/bin/bash
# ==========================================
# MCP心理专家系统一键部署脚本 (Ubuntu 24)
# ==========================================

set -e

echo "🚀 开始部署 MCP 心理专家系统..."
echo "=========================================="

# --------- 基础配置 ----------
PROJECT_DIR="/home/admin/mcp_full_project"
ENV_FILE="$PROJECT_DIR/.env"
export MCP_ENDPOINT="wss://api.xiaozhi.me/mcp/?token=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjM3NDAsImFnZW50SWQiOjk1NjYyMiwiZW5kcG9pbnRJZCI6ImFnZW50Xzk1NjYyMiIsInB1cnBvc2UiOiJtY3AtZW5kcG9pbnQiLCJpYXQiOjE3NjIwNzE2NDcsImV4cCI6MTc5MzYyOTI0N30._d5UJrMbUCRRLNMGmseLXixG_8v5j2fMCSldeVHTCGovGFuoSeFYnYcdXA4CBE-h5t-9UdyeJhD14zA8tXPeVw"
DB_NAME="mcp_db"
DB_USER="mcp_user"
DB_PASSWORD="*#06#Bcore*#06#"
BACKEND_PORT=8000
FRONTEND_PORT=8080
ADMIN_EMAIL="wgqabc2000@163.com"
ADMIN_USERNAME="admin"
ADMIN_PASSWORD="admin123"
SECRET_KEY=$(openssl rand -hex 16)

# --------- 系统环境安装 ----------
echo "📦 安装系统依赖..."
sudo apt update -y
sudo apt install -y python3 python3-pip python3-venv mysql-server unzip

# --------- 启动 MySQL ----------
echo "🧠 启动 MySQL..."
sudo systemctl enable mysql
sudo systemctl start mysql

# --------- 创建数据库与用户 ----------
echo "🛠️ 创建数据库与用户（如果不存在）..."
sudo mysql -u root <<EOF
CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
EOF

# --------- 创建虚拟环境 ----------
echo "🐍 创建 Python 虚拟环境..."
cd $PROJECT_DIR
python3 -m venv venv
source venv/bin/activate

echo "📦 安装 Python 依赖..."
pip install --upgrade pip
if [ -f "$PROJECT_DIR/requirements.txt" ]; then
    pip install -r requirements.txt
else
    pip install fastapi uvicorn sqlalchemy mysqlclient python-dotenv
fi

# --------- 生成 .env 文件 ----------
echo "⚙️ 生成 .env 配置文件..."
cat > $ENV_FILE <<EOL
APP_NAME=MCP心理专家系统
APP_ENV=production
APP_DEBUG=False
APP_PORT=${BACKEND_PORT}

DB_HOST=localhost
DB_PORT=3306
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASSWORD=${DB_PASSWORD}

ADMIN_EMAIL=${ADMIN_EMAIL}
ADMIN_USERNAME=${ADMIN_USERNAME}
ADMIN_PASSWORD=${ADMIN_PASSWORD}

MCP_TOOL_NAME=PsychologyExpert
MCP_DESCRIPTION=AI心理专家分析与报告生成
MCP_ENDPOINT=wss://api.xiaozhi.me/mcp/?token=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjM3NDAsImFnZW50SWQiOjk1NjYyMiwiZW5kcG9pbnRJZCI6ImFnZW50Xzk1NjYyMiIsInB1cnBvc2UiOiJtY3AtZW5kcG9pbnQiLCJpYXQiOjE3NjIwNzE2NDcsImV4cCI6MTc5MzYyOTI0N30._d5UJrMbUCRRLNMGmseLXixG_8v5j2fMCSldeVHTCGovGFuoSeFYnYcdXA4CBE-h5t-9UdyeJhD14zA8tXPeVw


SECRET_KEY=${SECRET_KEY}
FRONTEND_PORT=${FRONTEND_PORT}
EOL

echo "✅ 已生成 .env 文件"

# --------- 初始化数据库结构 ----------
if [ -f "$PROJECT_DIR/backend/init_db.py" ]; then
    echo "🧩 初始化数据库结构..."
    python3 $PROJECT_DIR/backend/init_db.py || echo "⚠️ 数据库初始化脚本执行失败，请手动检查。"
fi

# --------- 配置 systemd 服务 ----------
SERVICE_FILE="/etc/systemd/system/mcp_backend.service"
echo "⚙️ 创建 systemd 服务..."

sudo bash -c "cat > $SERVICE_FILE" <<EOL
[Unit]
Description=MCP Backend Service
After=network.target

[Service]
User=admin
WorkingDirectory=${PROJECT_DIR}/backend
EnvironmentFile=${ENV_FILE}
ExecStart=${PROJECT_DIR}/venv/bin/python3 main.py
Restart=always

[Install]
WantedBy=multi-user.target
EOL

sudo systemctl daemon-reload
sudo systemctl enable mcp_backend
sudo systemctl restart mcp_backend

# --------- 启动前端（如果存在） ----------
if [ -d "$PROJECT_DIR/frontend" ]; then
    echo "🌐 前端检测到，准备运行构建..."
    cd $PROJECT_DIR/frontend
    if [ -f "package.json" ]; then
        npm install
        npm run build
    fi
    echo "✅ 前端构建完成，端口：${FRONTEND_PORT}"
fi

# --------- 完成 ----------
echo "=========================================="

# Create systemd service to keep MCP pipe running
echo "🛠️ Creating systemd service for mcp_pipe..."
SERVICE_PATH="/etc/systemd/system/mcp_pipe.service"
cat > $SERVICE_PATH <<'UNIT'
[Unit]
Description=MCP Pipe Service
After=network.target

[Service]
Type=simple
User=admin
WorkingDirectory=/home/admin/mcp_full_project
Environment=MCP_ENDPOINT=wss://api.xiaozhi.me/mcp/?token=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjM3NDAsImFnZW50SWQiOjk1NjYyMiwiZW5kcG9pbnRJZCI6ImFnZW50Xzk1NjYyMiIsInB1cnBvc2UiOiJtY3AtZW5kcG9pbnQiLCJpYXQiOjE3NjIwNzE2NDcsImV4cCI6MTc5MzYyOTI0N30._d5UJrMbUCRRLNMGmseLXixG_8v5j2fMCSldeVHTCGovGFuoSeFYnYcdXA4CBE-h5t-9UdyeJhD14zA8tXPeVw
ExecStart=/usr/local/bin/python /home/admin/mcp_full_project/mcp_pipe.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable mcp_pipe
systemctl restart mcp_pipe

echo "🎉 部署完成！"
echo "👉 后端访问：http://<你的服务器IP>:${BACKEND_PORT}"
echo "👉 管理员账号：admin / admin123"
echo "=========================================="