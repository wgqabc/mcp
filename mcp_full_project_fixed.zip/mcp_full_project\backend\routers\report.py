from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from database.models import SessionLocal, Report
from sqlalchemy.orm import Session

router = APIRouter()

class ReportRequest(BaseModel):
    user_id: int
    content: str

@router.get("/{user_id}")
def get_report(user_id: int):
    db: Session = SessionLocal()
    report = db.query(Report).filter(Report.user_id == user_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="未找到心理报告")
    return {"success": True, "content": report.content}

@router.post("/")
def add_report(req: ReportRequest):
    db: Session = SessionLocal()
    report = Report(user_id=req.user_id, content=req.content)
    db.add(report)
    db.commit()
    return {"success": True}
