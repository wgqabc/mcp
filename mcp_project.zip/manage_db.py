# manage_db.py - create tables
from models import db, User, Report, KnowledgeItem, ToolRegistry
from app import create_app
import os

app = create_app()
app.app_context().push()

# Create tables
db.create_all()
print('Database tables created.')
