# MCP Project (Psych Expert + Management Web UI)

This package contains:
- A minimal Flask web application (user registration/login, reports CRUD, admin UI).
- A simple MCP psych expert tool (`psych_expert_server.py`) that registers an MCP tool via stdio.
- `mcp_pipe.py` (bridge) and `mcp_config.json` to connect local MCP tools to partner MCP manager.
- Deployment instructions for an Alibaba Cloud 2-core 2GB server and local MySQL.

## Contents
- app.py           -- Flask application (routes, templates)
- models.py        -- SQLAlchemy models
- manage_db.py     -- simple DB initialization script
- psych_expert_server.py -- MCP tool (stdio transport)
- mcp_pipe.py      -- bridge (from partner example)
- mcp_config.json  -- example config for mcp_pipe.py
- templates/       -- Jinja2 templates for minimal UI
- static/          -- CSS
- requirements.txt -- Python dependencies
- .env.example     -- example environment variables

## Quick start (recommended: create Python virtualenv)
1. Install Python 3.9+ and create virtualenv:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. Configure environment variables:
   ```bash
   cp .env.example .env
   # Edit .env with real values (SECRET_KEY, MySQL credentials, MCP endpoint)
   ```

3. Start MySQL (you can use local MySQL or RDS). Create database:
   ```sql
   CREATE DATABASE mcpdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

4. Initialize database tables:
   ```bash
   python manage_db.py
   ```

5. Run the Flask web app (development):
   ```bash
   export FLASK_APP=app.py
   flask run --host=0.0.0.0 --port=8000
   ```

6. Run MCP bridge to connect to partner MCP manager:
   ```bash
   export MCP_ENDPOINT="wss://partner.example.com/mcp"
   python mcp_pipe.py
   ```
   Or run a single local server:
   ```bash
   python mcp_pipe.py psych_expert_server.py
   ```

7. Run psych_expert_server (if not launched by mcp_pipe):
   ```bash
   python psych_expert_server.py
   ```

## Notes / Next steps
- This is a minimal PoC. For production, use:
  - Proper password hashing (werkzeug's generate_password_hash is used here).
  - HTTPS (Let's Encrypt).
  - Run Flask app behind a process manager (gunicorn + systemd) or in Docker.
  - Move MySQL to RDS for reliability.
  - Implement token-based auth for APIs if devices access backend directly.
  - Add logging/monitoring and backups.