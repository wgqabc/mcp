# app.py - Flask app with minimal pages for user and admin
import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from models import db, User, Report, KnowledgeItem
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

def create_app():
    app = Flask(__name__, template_folder='templates', static_folder='static')
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'devkey')
    user = os.getenv('MYSQL_USER', 'root')
    pwd = os.getenv('MYSQL_PASSWORD', '')
    host = os.getenv('MYSQL_HOST', '127.0.0.1')
    port = os.getenv('MYSQL_PORT','3306')
    dbn = os.getenv('MYSQL_DB','mcpdb')
    app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://{user}:{pwd}@{host}:{port}/{dbn}?charset=utf8mb4'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    register_routes(app)
    return app

def register_routes(app):
    @app.route('/')
    def index():
        if 'user_id' in session:
            return redirect(url_for('dashboard'))
        return render_template('index.html')

    @app.route('/register', methods=['GET','POST'])
    def register():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            if User.query.filter_by(username=username).first():
                flash('用户名已存在')
                return redirect(url_for('register'))
            user = User(username=username, password_hash=generate_password_hash(password))
            db.session.add(user)
            db.session.commit()
            flash('注册成功，请登录')
            return redirect(url_for('login'))
        return render_template('register.html')

    @app.route('/login', methods=['GET','POST'])
    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()
            if not user or not check_password_hash(user.password_hash, password):
                flash('用户名或密码错误')
                return redirect(url_for('login'))
            session['user_id'] = int(user.id)
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        return render_template('login.html')

    @app.route('/logout')
    def logout():
        session.clear()
        return redirect(url_for('index'))

    @app.route('/dashboard')
    def dashboard():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        uid = session['user_id']
        reports = Report.query.filter_by(user_id=uid).order_by(Report.report_date.desc()).all()
        return render_template('dashboard.html', reports=reports)

    @app.route('/report/new', methods=['GET','POST'])
    def report_new():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        if request.method == 'POST':
            title = request.form['title']
            content = request.form['content']
            # mark others as not latest
            uid = session['user_id']
            Report.query.filter_by(user_id=uid, is_latest=True).update({'is_latest': False})
            rpt = Report(user_id=uid, title=title, content=content, is_latest=True, report_date=datetime.utcnow().date())
            db.session.add(rpt)
            db.session.commit()
            flash('报告保存')
            return redirect(url_for('dashboard'))
        return render_template('report_edit.html')

    @app.route('/report/<int:report_id>/edit', methods=['GET','POST'])
    def report_edit(report_id):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        rpt = Report.query.get_or_404(report_id)
        if request.method == 'POST':
            rpt.title = request.form['title']
            rpt.content = request.form['content']
            db.session.commit()
            flash('保存成功')
            return redirect(url_for('dashboard'))
        return render_template('report_edit.html', report=rpt)

    # Admin pages
    @app.route('/admin')
    def admin_index():
        if session.get('role') != 'admin':
            return redirect(url_for('login'))
        users = User.query.all()
        return render_template('admin_index.html', users=users)

    @app.route('/admin/user/<int:user_id>', methods=['GET','POST'])
    def admin_user_edit(user_id):
        if session.get('role') != 'admin':
            return redirect(url_for('login'))
        user = User.query.get_or_404(user_id)
        if request.method == 'POST':
            user.display_name = request.form.get('display_name')
            user.device_id = request.form.get('device_id')
            db.session.commit()
            flash('保存成功')
            return redirect(url_for('admin_index'))
        reports = Report.query.filter_by(user_id=user.id).order_by(Report.report_date.desc()).all()
        return render_template('admin_user.html', user=user, reports=reports)

    @app.route('/api/user/<int:user_id>/reports/latest', methods=['GET'])
    def api_latest_report(user_id):
        # simple public endpoint (for device usage you should add auth)
        r = Report.query.filter_by(user_id=user_id, is_latest=True).first()
        if not r:
            r = Report.query.filter_by(user_id=user_id).order_by(Report.report_date.desc()).first()
        if not r:
            return jsonify(report=None)
        return jsonify({
            'id': r.id, 'title': r.title, 'content': r.content, 'report_date': r.report_date.isoformat() if r.report_date else None
        })

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=8000, debug=True)
