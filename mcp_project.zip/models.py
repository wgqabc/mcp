# models.py
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.BigInteger, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    display_name = db.Column(db.String(255))
    device_id = db.Column(db.String(128))
    role = db.Column(db.Enum('user','admin'), default='user')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Report(db.Model):
    __tablename__ = 'reports'
    id = db.Column(db.BigInteger, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(255))
    content = db.Column(db.Text, nullable=False)
    summary = db.Column(db.Text)
    score = db.Column(db.Float)
    report_date = db.Column(db.Date)
    is_latest = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class KnowledgeItem(db.Model):
    __tablename__ = 'knowledge_items'
    id = db.Column(db.BigInteger, primary_key=True)
    tool_key = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(255))
    content = db.Column(db.Text, nullable=False)
    tags = db.Column(db.String(255))
    version = db.Column(db.Integer, default=1)
    enabled = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.BigInteger)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ToolRegistry(db.Model):
    __tablename__ = 'tool_registry'
    id = db.Column(db.BigInteger, primary_key=True)
    tool_key = db.Column(db.String(100), unique=True)
    display_name = db.Column(db.String(255))
    type = db.Column(db.String(50))
    transport_type = db.Column(db.String(50), default='stdio')
    command_json = db.Column(db.Text)
    enabled = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
